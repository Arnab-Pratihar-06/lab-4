
public class CurrentAccount extends Account
{
	double overDraftLimit;

	public CurrentAccount() 
	{
		super();
	}
	
	public CurrentAccount(long accNumber,double balance,Person accHolder,double OverDraftLimit, double overDraftLimit)
	{
		super(accNumber,balance,accHolder);
		this.overDraftLimit=overDraftLimit;
	}
	
	public void withdraw(double m)throws OverDraftLimitSurpassed
	{
		if(m<=overDraftLimit)
			balance-=m;
		else
			throw new OverDraftLimitSurpassed();
	}
}
