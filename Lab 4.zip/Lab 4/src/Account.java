public class Account 
{
	long accNumber;
	double balance;
	Person accHolder;
	
	public Account()
	{
		
	}
	
	public Account(long accNumber,double balance,Person accHolder)
	{
		this.accNumber=accNumber;
		this.balance=balance;
		this.accHolder=accHolder;
	}

	public long getAccNumber() {
		return accNumber;
	}

	public void setAccNumber(long accNumber) {
		this.accNumber = accNumber;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public Person getAccHolder() {
		return accHolder;
	}

	public void setAccHolder(Person accHolder) {
		this.accHolder = accHolder;
	}
	
	public void deposit(double dAmount)
	{
		balance=balance+dAmount;
	}
	
	public void withdraw(double m)throws InsufficientBalanceException,OverDraftLimitSurpassed
	{
		if(balance-m>500)
			balance-=m;
		else
			throw new InsufficientBalanceException();
	}

	@Override
	public String toString() {
		return "Account [accNumber=" + accNumber + ", balance=" + balance
				+ ", accHolder=" + accHolder + "]";
	}
	
}

