
public class SavingAccount extends Account
{
	final double minBalance=500;

	public SavingAccount() 
	{
		super();
	}
	public SavingAccount(long accNumber,double balance,Person accHolder)
	{
		super(accNumber,balance,accHolder);
	}
	public void withdraw(double m)throws InsufficientBalanceException
	{
		if(balance-m>minBalance)
			balance-=m;
		else
			throw new InsufficientBalanceException();
	}
}
