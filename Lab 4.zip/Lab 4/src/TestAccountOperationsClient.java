
public class TestAccountOperationsClient 
{
	public static void main(String[] args) 
	{
		double acNo1=Math.random()*10000;
		double acNo2=Math.random()*10000;
		Person p1=new Person();
		p1.setName("Smith");
		p1.setAge(27);
		Account Smith=new Account((long)acNo1,2000,p1);
		
		Person p2=new Person();
		p2.setName("Kathy");
		p2.setAge(22);
		Account Kathy=new Account((long)acNo2,3000,p2);
		
		System.out.println("Initial account details of Smith : ");
		System.out.println(Smith);
		System.out.println();
		
		System.out.println("Initial account details of Kathy : ");
		System.out.println(Kathy);
		System.out.println();
		
		Smith.deposit(2000);
		System.out.println("Balance in Smith's Account : "+Smith.getBalance());
		
		Kathy.deposit(3000);
		System.out.println("Balance in Kathy's Account : "+Kathy.getBalance());
		
		try
		{
			Kathy.withdraw(2000);
			System.out.println("Balance in Kathy's account : "+Kathy.getBalance());
		}
		catch(Exception e)
		{
			
		}
	}
}
